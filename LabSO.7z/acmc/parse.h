#ifndef _PARSE_H_
#define _PARSE_H_

#include "globals.h"

// Função parse constrói e retorna a árvore sintática a partir do código fonte
TreeNode *parse(void);

#endif
