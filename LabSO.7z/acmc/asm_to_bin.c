#include <stdio.h>
#include <stdlib.h>
#include "binary_generator.h"

int main(int argc, char *argv[]) {
    if (argc < 2) {
        printf("Usage: %s <assembly_file.asm> [base_address]\n", argv[0]);
        return 1;
    }
    
    int base_address = 0;
    if (argc >= 3) {
        base_address = atoi(argv[2]);
    }
    
    generateBinaryWithAutoNaming(argv[1], base_address);
    return 0;
}
