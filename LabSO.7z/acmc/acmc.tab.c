/* A Bison parser, made by GNU Bison 3.8.2.  */

/* Bison implementation for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015, 2018-2021 Free Software Foundation,
   Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <https://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* C LALR(1) parser skeleton written by Richard Stallman, by
   simplifying the original so-called "semantic" parser.  */

/* DO NOT RELY ON FEATURES THAT ARE NOT DOCUMENTED in the manual,
   especially those whose name start with YY_ or yy_.  They are
   private implementation details that can be changed or removed.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Identify Bison output, and Bison version.  */
#define YYBISON 30802

/* Bison version string.  */
#define YYBISON_VERSION "3.8.2"

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 0

/* Push parsers.  */
#define YYPUSH 0

/* Pull parsers.  */
#define YYPULL 1




/* First part of user prologue.  */
#line 1 "acmc.y"

#define YYPARSER // Define para distinguir a saída do Yacc de outros arquivos

#include "globals.h"
#include "util.h"
#include "scan.h"

#define YYSTYPE TreeNode *
static TreeNode *savedTree; // Árvore de sintaxe abstrata gerada pelo parser
static int yylex(void);
int yyerror(char *msg);

#line 84 "acmc.tab.c"

# ifndef YY_CAST
#  ifdef __cplusplus
#   define YY_CAST(Type, Val) static_cast<Type> (Val)
#   define YY_REINTERPRET_CAST(Type, Val) reinterpret_cast<Type> (Val)
#  else
#   define YY_CAST(Type, Val) ((Type) (Val))
#   define YY_REINTERPRET_CAST(Type, Val) ((Type) (Val))
#  endif
# endif
# ifndef YY_NULLPTR
#  if defined __cplusplus
#   if 201103L <= __cplusplus
#    define YY_NULLPTR nullptr
#   else
#    define YY_NULLPTR 0
#   endif
#  else
#   define YY_NULLPTR ((void*)0)
#  endif
# endif

#include "acmc.tab.h"
/* Symbol kind.  */
enum yysymbol_kind_t
{
  YYSYMBOL_YYEMPTY = -2,
  YYSYMBOL_YYEOF = 0,                      /* "end of file"  */
  YYSYMBOL_YYerror = 1,                    /* error  */
  YYSYMBOL_YYUNDEF = 2,                    /* "invalid token"  */
  YYSYMBOL_NUM = 3,                        /* NUM  */
  YYSYMBOL_ID = 4,                         /* ID  */
  YYSYMBOL_IF = 5,                         /* IF  */
  YYSYMBOL_ELSE = 6,                       /* ELSE  */
  YYSYMBOL_WHILE = 7,                      /* WHILE  */
  YYSYMBOL_RETURN = 8,                     /* RETURN  */
  YYSYMBOL_VOID = 9,                       /* VOID  */
  YYSYMBOL_LOAD = 10,                      /* LOAD  */
  YYSYMBOL_QUANTUM = 11,                   /* QUANTUM  */
  YYSYMBOL_INT = 12,                       /* INT  */
  YYSYMBOL_ERROR = 13,                     /* ERROR  */
  YYSYMBOL_ENDFILE = 14,                   /* ENDFILE  */
  YYSYMBOL_MAIS = 15,                      /* MAIS  */
  YYSYMBOL_SUB = 16,                       /* SUB  */
  YYSYMBOL_MULT = 17,                      /* MULT  */
  YYSYMBOL_DIV = 18,                       /* DIV  */
  YYSYMBOL_MENOR = 19,                     /* MENOR  */
  YYSYMBOL_MENIG = 20,                     /* MENIG  */
  YYSYMBOL_MAIOR = 21,                     /* MAIOR  */
  YYSYMBOL_MAIIG = 22,                     /* MAIIG  */
  YYSYMBOL_IGDAD = 23,                     /* IGDAD  */
  YYSYMBOL_DIFER = 24,                     /* DIFER  */
  YYSYMBOL_IGUAL = 25,                     /* IGUAL  */
  YYSYMBOL_PV = 26,                        /* PV  */
  YYSYMBOL_VIR = 27,                       /* VIR  */
  YYSYMBOL_APAR = 28,                      /* APAR  */
  YYSYMBOL_FPAR = 29,                      /* FPAR  */
  YYSYMBOL_ACOL = 30,                      /* ACOL  */
  YYSYMBOL_FCOL = 31,                      /* FCOL  */
  YYSYMBOL_ACHAV = 32,                     /* ACHAV  */
  YYSYMBOL_FCHAV = 33,                     /* FCHAV  */
  YYSYMBOL_YYACCEPT = 34,                  /* $accept  */
  YYSYMBOL_programa = 35,                  /* programa  */
  YYSYMBOL_declaracao_lista = 36,          /* declaracao_lista  */
  YYSYMBOL_declaracao = 37,                /* declaracao  */
  YYSYMBOL_var_declaracao = 38,            /* var_declaracao  */
  YYSYMBOL_tipo_especificador = 39,        /* tipo_especificador  */
  YYSYMBOL_fun_declaracao = 40,            /* fun_declaracao  */
  YYSYMBOL_params = 41,                    /* params  */
  YYSYMBOL_param_lista = 42,               /* param_lista  */
  YYSYMBOL_param = 43,                     /* param  */
  YYSYMBOL_composto_decl = 44,             /* composto_decl  */
  YYSYMBOL_local_declaracoes = 45,         /* local_declaracoes  */
  YYSYMBOL_statement_lista = 46,           /* statement_lista  */
  YYSYMBOL_statement = 47,                 /* statement  */
  YYSYMBOL_expressao_decl = 48,            /* expressao_decl  */
  YYSYMBOL_selecao_decl = 49,              /* selecao_decl  */
  YYSYMBOL_iteracao_decl = 50,             /* iteracao_decl  */
  YYSYMBOL_retorno_decl = 51,              /* retorno_decl  */
  YYSYMBOL_load_decl = 52,                 /* load_decl  */
  YYSYMBOL_quantum_decl = 53,              /* quantum_decl  */
  YYSYMBOL_expressao = 54,                 /* expressao  */
  YYSYMBOL_var = 55,                       /* var  */
  YYSYMBOL_simples_expressao = 56,         /* simples_expressao  */
  YYSYMBOL_relacional = 57,                /* relacional  */
  YYSYMBOL_soma_expressao = 58,            /* soma_expressao  */
  YYSYMBOL_soma = 59,                      /* soma  */
  YYSYMBOL_termo = 60,                     /* termo  */
  YYSYMBOL_mult = 61,                      /* mult  */
  YYSYMBOL_fator = 62,                     /* fator  */
  YYSYMBOL_ativacao = 63,                  /* ativacao  */
  YYSYMBOL_arg_lista = 64,                 /* arg_lista  */
  YYSYMBOL_identificador = 65,             /* identificador  */
  YYSYMBOL_numero = 66                     /* numero  */
};
typedef enum yysymbol_kind_t yysymbol_kind_t;




#ifdef short
# undef short
#endif

/* On compilers that do not define __PTRDIFF_MAX__ etc., make sure
   <limits.h> and (if available) <stdint.h> are included
   so that the code can choose integer types of a good width.  */

#ifndef __PTRDIFF_MAX__
# include <limits.h> /* INFRINGES ON USER NAME SPACE */
# if defined __STDC_VERSION__ && 199901 <= __STDC_VERSION__
#  include <stdint.h> /* INFRINGES ON USER NAME SPACE */
#  define YY_STDINT_H
# endif
#endif

/* Narrow types that promote to a signed type and that can represent a
   signed or unsigned integer of at least N bits.  In tables they can
   save space and decrease cache pressure.  Promoting to a signed type
   helps avoid bugs in integer arithmetic.  */

#ifdef __INT_LEAST8_MAX__
typedef __INT_LEAST8_TYPE__ yytype_int8;
#elif defined YY_STDINT_H
typedef int_least8_t yytype_int8;
#else
typedef signed char yytype_int8;
#endif

#ifdef __INT_LEAST16_MAX__
typedef __INT_LEAST16_TYPE__ yytype_int16;
#elif defined YY_STDINT_H
typedef int_least16_t yytype_int16;
#else
typedef short yytype_int16;
#endif

/* Work around bug in HP-UX 11.23, which defines these macros
   incorrectly for preprocessor constants.  This workaround can likely
   be removed in 2023, as HPE has promised support for HP-UX 11.23
   (aka HP-UX 11i v2) only through the end of 2022; see Table 2 of
   <https://h20195.www2.hpe.com/V2/getpdf.aspx/4AA4-7673ENW.pdf>.  */
#ifdef __hpux
# undef UINT_LEAST8_MAX
# undef UINT_LEAST16_MAX
# define UINT_LEAST8_MAX 255
# define UINT_LEAST16_MAX 65535
#endif

#if defined __UINT_LEAST8_MAX__ && __UINT_LEAST8_MAX__ <= __INT_MAX__
typedef __UINT_LEAST8_TYPE__ yytype_uint8;
#elif (!defined __UINT_LEAST8_MAX__ && defined YY_STDINT_H \
       && UINT_LEAST8_MAX <= INT_MAX)
typedef uint_least8_t yytype_uint8;
#elif !defined __UINT_LEAST8_MAX__ && UCHAR_MAX <= INT_MAX
typedef unsigned char yytype_uint8;
#else
typedef short yytype_uint8;
#endif

#if defined __UINT_LEAST16_MAX__ && __UINT_LEAST16_MAX__ <= __INT_MAX__
typedef __UINT_LEAST16_TYPE__ yytype_uint16;
#elif (!defined __UINT_LEAST16_MAX__ && defined YY_STDINT_H \
       && UINT_LEAST16_MAX <= INT_MAX)
typedef uint_least16_t yytype_uint16;
#elif !defined __UINT_LEAST16_MAX__ && USHRT_MAX <= INT_MAX
typedef unsigned short yytype_uint16;
#else
typedef int yytype_uint16;
#endif

#ifndef YYPTRDIFF_T
# if defined __PTRDIFF_TYPE__ && defined __PTRDIFF_MAX__
#  define YYPTRDIFF_T __PTRDIFF_TYPE__
#  define YYPTRDIFF_MAXIMUM __PTRDIFF_MAX__
# elif defined PTRDIFF_MAX
#  ifndef ptrdiff_t
#   include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  endif
#  define YYPTRDIFF_T ptrdiff_t
#  define YYPTRDIFF_MAXIMUM PTRDIFF_MAX
# else
#  define YYPTRDIFF_T long
#  define YYPTRDIFF_MAXIMUM LONG_MAX
# endif
#endif

#ifndef YYSIZE_T
# ifdef __SIZE_TYPE__
#  define YYSIZE_T __SIZE_TYPE__
# elif defined size_t
#  define YYSIZE_T size_t
# elif defined __STDC_VERSION__ && 199901 <= __STDC_VERSION__
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# else
#  define YYSIZE_T unsigned
# endif
#endif

#define YYSIZE_MAXIMUM                                  \
  YY_CAST (YYPTRDIFF_T,                                 \
           (YYPTRDIFF_MAXIMUM < YY_CAST (YYSIZE_T, -1)  \
            ? YYPTRDIFF_MAXIMUM                         \
            : YY_CAST (YYSIZE_T, -1)))

#define YYSIZEOF(X) YY_CAST (YYPTRDIFF_T, sizeof (X))


/* Stored state numbers (used for stacks). */
typedef yytype_int8 yy_state_t;

/* State numbers in computations.  */
typedef int yy_state_fast_t;

#ifndef YY_
# if defined YYENABLE_NLS && YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* INFRINGES ON USER NAME SPACE */
#   define YY_(Msgid) dgettext ("bison-runtime", Msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(Msgid) Msgid
# endif
#endif


#ifndef YY_ATTRIBUTE_PURE
# if defined __GNUC__ && 2 < __GNUC__ + (96 <= __GNUC_MINOR__)
#  define YY_ATTRIBUTE_PURE __attribute__ ((__pure__))
# else
#  define YY_ATTRIBUTE_PURE
# endif
#endif

#ifndef YY_ATTRIBUTE_UNUSED
# if defined __GNUC__ && 2 < __GNUC__ + (7 <= __GNUC_MINOR__)
#  define YY_ATTRIBUTE_UNUSED __attribute__ ((__unused__))
# else
#  define YY_ATTRIBUTE_UNUSED
# endif
#endif

/* Suppress unused-variable warnings by "using" E.  */
#if ! defined lint || defined __GNUC__
# define YY_USE(E) ((void) (E))
#else
# define YY_USE(E) /* empty */
#endif

/* Suppress an incorrect diagnostic about yylval being uninitialized.  */
#if defined __GNUC__ && ! defined __ICC && 406 <= __GNUC__ * 100 + __GNUC_MINOR__
# if __GNUC__ * 100 + __GNUC_MINOR__ < 407
#  define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN                           \
    _Pragma ("GCC diagnostic push")                                     \
    _Pragma ("GCC diagnostic ignored \"-Wuninitialized\"")
# else
#  define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN                           \
    _Pragma ("GCC diagnostic push")                                     \
    _Pragma ("GCC diagnostic ignored \"-Wuninitialized\"")              \
    _Pragma ("GCC diagnostic ignored \"-Wmaybe-uninitialized\"")
# endif
# define YY_IGNORE_MAYBE_UNINITIALIZED_END      \
    _Pragma ("GCC diagnostic pop")
#else
# define YY_INITIAL_VALUE(Value) Value
#endif
#ifndef YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_END
#endif
#ifndef YY_INITIAL_VALUE
# define YY_INITIAL_VALUE(Value) /* Nothing. */
#endif

#if defined __cplusplus && defined __GNUC__ && ! defined __ICC && 6 <= __GNUC__
# define YY_IGNORE_USELESS_CAST_BEGIN                          \
    _Pragma ("GCC diagnostic push")                            \
    _Pragma ("GCC diagnostic ignored \"-Wuseless-cast\"")
# define YY_IGNORE_USELESS_CAST_END            \
    _Pragma ("GCC diagnostic pop")
#endif
#ifndef YY_IGNORE_USELESS_CAST_BEGIN
# define YY_IGNORE_USELESS_CAST_BEGIN
# define YY_IGNORE_USELESS_CAST_END
#endif


#define YY_ASSERT(E) ((void) (0 && (E)))

#if !defined yyoverflow

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# ifdef YYSTACK_USE_ALLOCA
#  if YYSTACK_USE_ALLOCA
#   ifdef __GNUC__
#    define YYSTACK_ALLOC __builtin_alloca
#   elif defined __BUILTIN_VA_ARG_INCR
#    include <alloca.h> /* INFRINGES ON USER NAME SPACE */
#   elif defined _AIX
#    define YYSTACK_ALLOC __alloca
#   elif defined _MSC_VER
#    include <malloc.h> /* INFRINGES ON USER NAME SPACE */
#    define alloca _alloca
#   else
#    define YYSTACK_ALLOC alloca
#    if ! defined _ALLOCA_H && ! defined EXIT_SUCCESS
#     include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
      /* Use EXIT_SUCCESS as a witness for stdlib.h.  */
#     ifndef EXIT_SUCCESS
#      define EXIT_SUCCESS 0
#     endif
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's 'empty if-body' warning.  */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (0)
#  ifndef YYSTACK_ALLOC_MAXIMUM
    /* The OS might guarantee only one guard page at the bottom of the stack,
       and a page size can be as small as 4096 bytes.  So we cannot safely
       invoke alloca (N) if N exceeds 4096.  Use a slightly smaller number
       to allow for a few compiler-allocated temporary stack slots.  */
#   define YYSTACK_ALLOC_MAXIMUM 4032 /* reasonable circa 2006 */
#  endif
# else
#  define YYSTACK_ALLOC YYMALLOC
#  define YYSTACK_FREE YYFREE
#  ifndef YYSTACK_ALLOC_MAXIMUM
#   define YYSTACK_ALLOC_MAXIMUM YYSIZE_MAXIMUM
#  endif
#  if (defined __cplusplus && ! defined EXIT_SUCCESS \
       && ! ((defined YYMALLOC || defined malloc) \
             && (defined YYFREE || defined free)))
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   ifndef EXIT_SUCCESS
#    define EXIT_SUCCESS 0
#   endif
#  endif
#  ifndef YYMALLOC
#   define YYMALLOC malloc
#   if ! defined malloc && ! defined EXIT_SUCCESS
void *malloc (YYSIZE_T); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
#  ifndef YYFREE
#   define YYFREE free
#   if ! defined free && ! defined EXIT_SUCCESS
void free (void *); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
# endif
#endif /* !defined yyoverflow */

#if (! defined yyoverflow \
     && (! defined __cplusplus \
         || (defined YYSTYPE_IS_TRIVIAL && YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  yy_state_t yyss_alloc;
  YYSTYPE yyvs_alloc;
};

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (YYSIZEOF (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (YYSIZEOF (yy_state_t) + YYSIZEOF (YYSTYPE)) \
      + YYSTACK_GAP_MAXIMUM)

# define YYCOPY_NEEDED 1

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack_alloc, Stack)                           \
    do                                                                  \
      {                                                                 \
        YYPTRDIFF_T yynewbytes;                                         \
        YYCOPY (&yyptr->Stack_alloc, Stack, yysize);                    \
        Stack = &yyptr->Stack_alloc;                                    \
        yynewbytes = yystacksize * YYSIZEOF (*Stack) + YYSTACK_GAP_MAXIMUM; \
        yyptr += yynewbytes / YYSIZEOF (*yyptr);                        \
      }                                                                 \
    while (0)

#endif

#if defined YYCOPY_NEEDED && YYCOPY_NEEDED
/* Copy COUNT objects from SRC to DST.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if defined __GNUC__ && 1 < __GNUC__
#   define YYCOPY(Dst, Src, Count) \
      __builtin_memcpy (Dst, Src, YY_CAST (YYSIZE_T, (Count)) * sizeof (*(Src)))
#  else
#   define YYCOPY(Dst, Src, Count)              \
      do                                        \
        {                                       \
          YYPTRDIFF_T yyi;                      \
          for (yyi = 0; yyi < (Count); yyi++)   \
            (Dst)[yyi] = (Src)[yyi];            \
        }                                       \
      while (0)
#  endif
# endif
#endif /* !YYCOPY_NEEDED */

/* YYFINAL -- State number of the termination state.  */
#define YYFINAL  11
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   155

/* YYNTOKENS -- Number of terminals.  */
#define YYNTOKENS  34
/* YYNNTS -- Number of nonterminals.  */
#define YYNNTS  33
/* YYNRULES -- Number of rules.  */
#define YYNRULES  72
/* YYNSTATES -- Number of states.  */
#define YYNSTATES  124

/* YYMAXUTOK -- Last valid token kind.  */
#define YYMAXUTOK   288


/* YYTRANSLATE(TOKEN-NUM) -- Symbol number corresponding to TOKEN-NUM
   as returned by yylex, with out-of-bounds checking.  */
#define YYTRANSLATE(YYX)                                \
  (0 <= (YYX) && (YYX) <= YYMAXUTOK                     \
   ? YY_CAST (yysymbol_kind_t, yytranslate[YYX])        \
   : YYSYMBOL_YYUNDEF)

/* YYTRANSLATE[TOKEN-NUM] -- Symbol number corresponding to TOKEN-NUM
   as returned by yylex.  */
static const yytype_int8 yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33
};

#if YYDEBUG
/* YYRLINE[YYN] -- Source line where rule number YYN was defined.  */
static const yytype_int16 yyrline[] =
{
       0,    29,    29,    34,    46,    50,    51,    55,    65,    80,
      88,    99,   110,   124,   125,   136,   148,   152,   159,   170,
     182,   183,   184,   188,   200,   204,   216,   220,   221,   222,
     223,   224,   225,   226,   230,   231,   235,   242,   253,   263,
     268,   277,   285,   293,   300,   304,   306,   316,   323,   327,
     333,   339,   345,   351,   357,   366,   373,   377,   383,   392,
     399,   403,   409,   418,   423,   428,   433,   441,   448,   457,
     469,   473,   482
};
#endif

/** Accessing symbol of state STATE.  */
#define YY_ACCESSING_SYMBOL(State) YY_CAST (yysymbol_kind_t, yystos[State])

#if YYDEBUG || 0
/* The user-facing name of the symbol whose (internal) number is
   YYSYMBOL.  No bounds checking.  */
static const char *yysymbol_name (yysymbol_kind_t yysymbol) YY_ATTRIBUTE_UNUSED;

/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals.  */
static const char *const yytname[] =
{
  "\"end of file\"", "error", "\"invalid token\"", "NUM", "ID", "IF",
  "ELSE", "WHILE", "RETURN", "VOID", "LOAD", "QUANTUM", "INT", "ERROR",
  "ENDFILE", "MAIS", "SUB", "MULT", "DIV", "MENOR", "MENIG", "MAIOR",
  "MAIIG", "IGDAD", "DIFER", "IGUAL", "PV", "VIR", "APAR", "FPAR", "ACOL",
  "FCOL", "ACHAV", "FCHAV", "$accept", "programa", "declaracao_lista",
  "declaracao", "var_declaracao", "tipo_especificador", "fun_declaracao",
  "params", "param_lista", "param", "composto_decl", "local_declaracoes",
  "statement_lista", "statement", "expressao_decl", "selecao_decl",
  "iteracao_decl", "retorno_decl", "load_decl", "quantum_decl",
  "expressao", "var", "simples_expressao", "relacional", "soma_expressao",
  "soma", "termo", "mult", "fator", "ativacao", "arg_lista",
  "identificador", "numero", YY_NULLPTR
};

static const char *
yysymbol_name (yysymbol_kind_t yysymbol)
{
  return yytname[yysymbol];
}
#endif

#define YYPACT_NINF (-56)

#define yypact_value_is_default(Yyn) \
  ((Yyn) == YYPACT_NINF)

#define YYTABLE_NINF (-15)

#define yytable_value_is_error(Yyn) \
  0

/* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
   STATE-NUM.  */
static const yytype_int16 yypact[] =
{
      70,     8,     8,    23,    70,   -56,   -56,   -56,   -56,     7,
      42,   -56,   -56,    80,   -56,    80,    48,    35,   -56,     8,
      40,    20,   -56,    71,   -56,    21,    72,    75,    86,    75,
      77,    79,     6,   -56,   -56,   -56,   -56,   -56,   -56,    76,
      84,    22,    18,    18,     8,   -56,    18,   -56,   -56,   -56,
      73,    83,   -56,   -56,   -56,   -56,   -56,   -56,   -56,    82,
      88,   -56,    38,    25,   -56,   -56,     1,   -56,    18,    18,
     -56,    94,    97,   103,   -22,    85,   -56,   -56,   114,   -56,
     -56,   -56,    18,   -56,   -56,   -56,   -56,   -56,   -56,   -56,
     -56,    18,    18,   -56,   -56,    18,    16,    18,   106,   107,
     -56,   -56,   -56,   -56,   -56,   -56,   -56,    81,    25,   -56,
     -56,   -56,    36,   101,   123,   123,    18,   -56,   -56,   131,
     -56,   -56,   123,   -56
};

/* YYDEFACT[STATE-NUM] -- Default reduction number in state STATE-NUM.
   Performed when YYTABLE does not specify something else to do.  Zero
   means the default is an error.  */
static const yytype_int8 yydefact[] =
{
       0,     0,     0,     0,     2,     4,     5,     6,    71,     0,
       0,     1,     3,     0,     7,     0,     0,    10,     9,     0,
       0,    13,    16,     0,    72,     0,    17,     0,     0,     0,
       0,     0,     0,    12,    10,    15,    11,     8,    18,     0,
       0,     0,     0,     0,     0,    35,     0,    20,    24,    28,
       0,     0,    26,    27,    29,    30,    31,    32,    33,     0,
      64,    44,    48,    56,    60,    65,    45,    66,     0,     0,
      39,     0,     0,     0,     0,     0,    21,    23,     0,    22,
      25,    34,     0,    57,    58,    49,    50,    51,    52,    53,
      54,     0,     0,    61,    62,     0,     0,     0,     0,     0,
      40,    41,    42,    63,    19,    43,    64,    47,    55,    59,
      68,    70,     0,     0,     0,     0,     0,    67,    46,    36,
      38,    69,     0,    37
};

/* YYPGOTO[NTERM-NUM].  */
static const yytype_int16 yypgoto[] =
{
     -56,   -56,   -56,   134,   -17,   -56,   -56,   124,   -56,   113,
      44,   -56,    93,   -48,   -56,   -56,   -56,   -56,   -56,   -56,
     -41,   -55,   -56,   -56,    53,   -56,    56,   -56,    50,   -56,
     -56,     5,   136
};

/* YYDEFGOTO[NTERM-NUM].  */
static const yytype_int8 yydefgoto[] =
{
       0,     3,     4,     5,     6,    19,     7,    20,    21,    22,
      49,    50,    51,    52,    53,    54,    55,    56,    57,    58,
      59,    60,    61,    91,    62,    92,    63,    95,    64,    65,
     112,    66,    67
};

/* YYTABLE[YYPACT[STATE-NUM]] -- What to do in state STATE-NUM.  If
   positive, shift that token.  If negative, reduce the rule whose
   number is the opposite.  If YYTABLE_NINF, syntax error.  */
static const yytype_int8 yytable[] =
{
      71,    72,    73,    80,    14,    75,     9,    10,    16,    24,
       8,    39,     8,    40,    41,    48,    42,    43,    44,    24,
       8,    24,     8,    11,    26,    24,     8,    98,    99,    96,
      80,    97,    45,    77,    46,    13,   106,   106,    32,    47,
     106,   105,    93,    94,    46,   110,    46,    28,    70,    74,
      46,    24,    30,    83,    84,   111,   113,    85,    86,    87,
      88,    89,    90,   116,   -14,   117,   119,   120,    14,    27,
      15,    33,    16,    36,   123,   121,    24,     8,    39,     1,
      40,    41,     2,    42,    43,    44,    24,     8,    39,    17,
      40,    41,    18,    42,    43,    34,    83,    84,    18,    45,
      29,    46,    31,    37,    68,    32,    76,    32,    81,    45,
      38,    46,    69,    82,   103,    32,    79,    24,     8,    39,
     100,    40,    41,   101,    42,    43,    24,     8,    39,   102,
      40,    41,   118,    42,    43,   114,   115,   122,    12,    23,
      45,    35,    46,    78,   107,   109,    32,   104,   108,    45,
       0,    46,    25,     0,     0,    32
};

static const yytype_int8 yycheck[] =
{
      41,    42,    43,    51,    26,    46,     1,     2,    30,     3,
       4,     5,     4,     7,     8,    32,    10,    11,    12,     3,
       4,     3,     4,     0,    19,     3,     4,    68,    69,    28,
      78,    30,    26,    50,    28,    28,    91,    92,    32,    33,
      95,    82,    17,    18,    28,    29,    28,    27,    26,    44,
      28,     3,    31,    15,    16,    96,    97,    19,    20,    21,
      22,    23,    24,    27,    29,    29,   114,   115,    26,    29,
      28,    27,    30,    29,   122,   116,     3,     4,     5,     9,
       7,     8,    12,    10,    11,    12,     3,     4,     5,     9,
       7,     8,    12,    10,    11,     9,    15,    16,    12,    26,
      29,    28,    30,    26,    28,    32,    33,    32,    26,    26,
      31,    28,    28,    25,    29,    32,    33,     3,     4,     5,
      26,     7,     8,    26,    10,    11,     3,     4,     5,    26,
       7,     8,    31,    10,    11,    29,    29,     6,     4,    15,
      26,    28,    28,    50,    91,    95,    32,    33,    92,    26,
      -1,    28,    16,    -1,    -1,    32
};

/* YYSTOS[STATE-NUM] -- The symbol kind of the accessing symbol of
   state STATE-NUM.  */
static const yytype_int8 yystos[] =
{
       0,     9,    12,    35,    36,    37,    38,    40,     4,    65,
      65,     0,    37,    28,    26,    28,    30,     9,    12,    39,
      41,    42,    43,    41,     3,    66,    65,    29,    27,    29,
      31,    30,    32,    44,     9,    43,    44,    26,    31,     5,
       7,     8,    10,    11,    12,    26,    28,    33,    38,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    56,    58,    60,    62,    63,    65,    66,    28,    28,
      26,    54,    54,    54,    65,    54,    33,    38,    46,    33,
      47,    26,    25,    15,    16,    19,    20,    21,    22,    23,
      24,    57,    59,    17,    18,    61,    28,    30,    54,    54,
      26,    26,    26,    29,    33,    54,    55,    58,    60,    62,
      29,    54,    64,    54,    29,    29,    27,    29,    31,    47,
      47,    54,     6,    47
};

/* YYR1[RULE-NUM] -- Symbol kind of the left-hand side of rule RULE-NUM.  */
static const yytype_int8 yyr1[] =
{
       0,    34,    35,    36,    36,    37,    37,    38,    38,    39,
      39,    40,    40,    41,    41,    42,    42,    43,    43,    44,
      44,    44,    44,    45,    45,    46,    46,    47,    47,    47,
      47,    47,    47,    47,    48,    48,    49,    49,    50,    51,
      51,    52,    53,    54,    54,    55,    55,    56,    56,    57,
      57,    57,    57,    57,    57,    58,    58,    59,    59,    60,
      60,    61,    61,    62,    62,    62,    62,    63,    63,    64,
      64,    65,    66
};

/* YYR2[RULE-NUM] -- Number of symbols on the right-hand side of rule RULE-NUM.  */
static const yytype_int8 yyr2[] =
{
       0,     2,     1,     2,     1,     1,     1,     3,     6,     1,
       1,     6,     6,     1,     1,     3,     1,     2,     4,     4,
       2,     3,     3,     2,     1,     2,     1,     1,     1,     1,
       1,     1,     1,     1,     2,     1,     5,     7,     5,     2,
       3,     3,     3,     3,     1,     1,     4,     3,     1,     1,
       1,     1,     1,     1,     1,     3,     1,     1,     1,     3,
       1,     1,     1,     3,     1,     1,     1,     4,     3,     3,
       1,     1,     1
};


enum { YYENOMEM = -2 };

#define yyerrok         (yyerrstatus = 0)
#define yyclearin       (yychar = YYEMPTY)

#define YYACCEPT        goto yyacceptlab
#define YYABORT         goto yyabortlab
#define YYERROR         goto yyerrorlab
#define YYNOMEM         goto yyexhaustedlab


#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)                                    \
  do                                                              \
    if (yychar == YYEMPTY)                                        \
      {                                                           \
        yychar = (Token);                                         \
        yylval = (Value);                                         \
        YYPOPSTACK (yylen);                                       \
        yystate = *yyssp;                                         \
        goto yybackup;                                            \
      }                                                           \
    else                                                          \
      {                                                           \
        yyerror (YY_("syntax error: cannot back up")); \
        YYERROR;                                                  \
      }                                                           \
  while (0)

/* Backward compatibility with an undocumented macro.
   Use YYerror or YYUNDEF. */
#define YYERRCODE YYUNDEF


/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)                        \
do {                                            \
  if (yydebug)                                  \
    YYFPRINTF Args;                             \
} while (0)




# define YY_SYMBOL_PRINT(Title, Kind, Value, Location)                    \
do {                                                                      \
  if (yydebug)                                                            \
    {                                                                     \
      YYFPRINTF (stderr, "%s ", Title);                                   \
      yy_symbol_print (stderr,                                            \
                  Kind, Value); \
      YYFPRINTF (stderr, "\n");                                           \
    }                                                                     \
} while (0)


/*-----------------------------------.
| Print this symbol's value on YYO.  |
`-----------------------------------*/

static void
yy_symbol_value_print (FILE *yyo,
                       yysymbol_kind_t yykind, YYSTYPE const * const yyvaluep)
{
  FILE *yyoutput = yyo;
  YY_USE (yyoutput);
  if (!yyvaluep)
    return;
  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  YY_USE (yykind);
  YY_IGNORE_MAYBE_UNINITIALIZED_END
}


/*---------------------------.
| Print this symbol on YYO.  |
`---------------------------*/

static void
yy_symbol_print (FILE *yyo,
                 yysymbol_kind_t yykind, YYSTYPE const * const yyvaluep)
{
  YYFPRINTF (yyo, "%s %s (",
             yykind < YYNTOKENS ? "token" : "nterm", yysymbol_name (yykind));

  yy_symbol_value_print (yyo, yykind, yyvaluep);
  YYFPRINTF (yyo, ")");
}

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (included).                                                   |
`------------------------------------------------------------------*/

static void
yy_stack_print (yy_state_t *yybottom, yy_state_t *yytop)
{
  YYFPRINTF (stderr, "Stack now");
  for (; yybottom <= yytop; yybottom++)
    {
      int yybot = *yybottom;
      YYFPRINTF (stderr, " %d", yybot);
    }
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)                            \
do {                                                            \
  if (yydebug)                                                  \
    yy_stack_print ((Bottom), (Top));                           \
} while (0)


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

static void
yy_reduce_print (yy_state_t *yyssp, YYSTYPE *yyvsp,
                 int yyrule)
{
  int yylno = yyrline[yyrule];
  int yynrhs = yyr2[yyrule];
  int yyi;
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %d):\n",
             yyrule - 1, yylno);
  /* The symbols being reduced.  */
  for (yyi = 0; yyi < yynrhs; yyi++)
    {
      YYFPRINTF (stderr, "   $%d = ", yyi + 1);
      yy_symbol_print (stderr,
                       YY_ACCESSING_SYMBOL (+yyssp[yyi + 1 - yynrhs]),
                       &yyvsp[(yyi + 1) - (yynrhs)]);
      YYFPRINTF (stderr, "\n");
    }
}

# define YY_REDUCE_PRINT(Rule)          \
do {                                    \
  if (yydebug)                          \
    yy_reduce_print (yyssp, yyvsp, Rule); \
} while (0)

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args) ((void) 0)
# define YY_SYMBOL_PRINT(Title, Kind, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !YYDEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   YYSTACK_ALLOC_MAXIMUM < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif






/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

static void
yydestruct (const char *yymsg,
            yysymbol_kind_t yykind, YYSTYPE *yyvaluep)
{
  YY_USE (yyvaluep);
  if (!yymsg)
    yymsg = "Deleting";
  YY_SYMBOL_PRINT (yymsg, yykind, yyvaluep, yylocationp);

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  YY_USE (yykind);
  YY_IGNORE_MAYBE_UNINITIALIZED_END
}


/* Lookahead token kind.  */
int yychar;

/* The semantic value of the lookahead symbol.  */
YYSTYPE yylval;
/* Number of syntax errors so far.  */
int yynerrs;




/*----------.
| yyparse.  |
`----------*/

int
yyparse (void)
{
    yy_state_fast_t yystate = 0;
    /* Number of tokens to shift before error messages enabled.  */
    int yyerrstatus = 0;

    /* Refer to the stacks through separate pointers, to allow yyoverflow
       to reallocate them elsewhere.  */

    /* Their size.  */
    YYPTRDIFF_T yystacksize = YYINITDEPTH;

    /* The state stack: array, bottom, top.  */
    yy_state_t yyssa[YYINITDEPTH];
    yy_state_t *yyss = yyssa;
    yy_state_t *yyssp = yyss;

    /* The semantic value stack: array, bottom, top.  */
    YYSTYPE yyvsa[YYINITDEPTH];
    YYSTYPE *yyvs = yyvsa;
    YYSTYPE *yyvsp = yyvs;

  int yyn;
  /* The return value of yyparse.  */
  int yyresult;
  /* Lookahead symbol kind.  */
  yysymbol_kind_t yytoken = YYSYMBOL_YYEMPTY;
  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;



#define YYPOPSTACK(N)   (yyvsp -= (N), yyssp -= (N))

  /* The number of symbols on the RHS of the reduced rule.
     Keep to zero when no symbol should be popped.  */
  int yylen = 0;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yychar = YYEMPTY; /* Cause a token to be read.  */

  goto yysetstate;


/*------------------------------------------------------------.
| yynewstate -- push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed.  So pushing a state here evens the stacks.  */
  yyssp++;


/*--------------------------------------------------------------------.
| yysetstate -- set current state (the top of the stack) to yystate.  |
`--------------------------------------------------------------------*/
yysetstate:
  YYDPRINTF ((stderr, "Entering state %d\n", yystate));
  YY_ASSERT (0 <= yystate && yystate < YYNSTATES);
  YY_IGNORE_USELESS_CAST_BEGIN
  *yyssp = YY_CAST (yy_state_t, yystate);
  YY_IGNORE_USELESS_CAST_END
  YY_STACK_PRINT (yyss, yyssp);

  if (yyss + yystacksize - 1 <= yyssp)
#if !defined yyoverflow && !defined YYSTACK_RELOCATE
    YYNOMEM;
#else
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYPTRDIFF_T yysize = yyssp - yyss + 1;

# if defined yyoverflow
      {
        /* Give user a chance to reallocate the stack.  Use copies of
           these so that the &'s don't force the real ones into
           memory.  */
        yy_state_t *yyss1 = yyss;
        YYSTYPE *yyvs1 = yyvs;

        /* Each stack pointer address is followed by the size of the
           data in use in that stack, in bytes.  This used to be a
           conditional around just the two extra args, but that might
           be undefined if yyoverflow is a macro.  */
        yyoverflow (YY_("memory exhausted"),
                    &yyss1, yysize * YYSIZEOF (*yyssp),
                    &yyvs1, yysize * YYSIZEOF (*yyvsp),
                    &yystacksize);
        yyss = yyss1;
        yyvs = yyvs1;
      }
# else /* defined YYSTACK_RELOCATE */
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
        YYNOMEM;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
        yystacksize = YYMAXDEPTH;

      {
        yy_state_t *yyss1 = yyss;
        union yyalloc *yyptr =
          YY_CAST (union yyalloc *,
                   YYSTACK_ALLOC (YY_CAST (YYSIZE_T, YYSTACK_BYTES (yystacksize))));
        if (! yyptr)
          YYNOMEM;
        YYSTACK_RELOCATE (yyss_alloc, yyss);
        YYSTACK_RELOCATE (yyvs_alloc, yyvs);
#  undef YYSTACK_RELOCATE
        if (yyss1 != yyssa)
          YYSTACK_FREE (yyss1);
      }
# endif

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;

      YY_IGNORE_USELESS_CAST_BEGIN
      YYDPRINTF ((stderr, "Stack size increased to %ld\n",
                  YY_CAST (long, yystacksize)));
      YY_IGNORE_USELESS_CAST_END

      if (yyss + yystacksize - 1 <= yyssp)
        YYABORT;
    }
#endif /* !defined yyoverflow && !defined YYSTACK_RELOCATE */


  if (yystate == YYFINAL)
    YYACCEPT;

  goto yybackup;


/*-----------.
| yybackup.  |
`-----------*/
yybackup:
  /* Do appropriate processing given the current state.  Read a
     lookahead token if we need one and don't already have one.  */

  /* First try to decide what to do without reference to lookahead token.  */
  yyn = yypact[yystate];
  if (yypact_value_is_default (yyn))
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* YYCHAR is either empty, or end-of-input, or a valid lookahead.  */
  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token\n"));
      yychar = yylex ();
    }

  if (yychar <= YYEOF)
    {
      yychar = YYEOF;
      yytoken = YYSYMBOL_YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else if (yychar == YYerror)
    {
      /* The scanner already issued an error message, process directly
         to error recovery.  But do not keep the error token as
         lookahead, it is too special and may lead us to an endless
         loop in error recovery. */
      yychar = YYUNDEF;
      yytoken = YYSYMBOL_YYerror;
      goto yyerrlab1;
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YY_SYMBOL_PRINT ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yytable_value_is_error (yyn))
        goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  /* Shift the lookahead token.  */
  YY_SYMBOL_PRINT ("Shifting", yytoken, &yylval, &yylloc);
  yystate = yyn;
  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END

  /* Discard the shifted token.  */
  yychar = YYEMPTY;
  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     '$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];


  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
  case 2: /* programa: declaracao_lista  */
#line 30 "acmc.y"
           { savedTree = yyvsp[0]; }
#line 1229 "acmc.tab.c"
    break;

  case 3: /* declaracao_lista: declaracao_lista declaracao  */
#line 35 "acmc.y"
           { 
              // Concatena declarações em uma lista encadeada
              YYSTYPE t = yyvsp[-1];
              if (t != NULL){
                while (t->sibling != NULL)
                   t = t->sibling;
                t->sibling = yyvsp[0];
                yyval = yyvsp[-1];
              }
              else yyval = yyvsp[0];
           }
#line 1245 "acmc.tab.c"
    break;

  case 4: /* declaracao_lista: declaracao  */
#line 46 "acmc.y"
                       { yyval = yyvsp[0]; }
#line 1251 "acmc.tab.c"
    break;

  case 5: /* declaracao: var_declaracao  */
#line 50 "acmc.y"
                            { yyval = yyvsp[0]; }
#line 1257 "acmc.tab.c"
    break;

  case 6: /* declaracao: fun_declaracao  */
#line 51 "acmc.y"
                            { yyval = yyvsp[0]; }
#line 1263 "acmc.tab.c"
    break;

  case 7: /* var_declaracao: INT identificador PV  */
#line 56 "acmc.y"
           { 
              // Declaração de variável simples
              yyval = newExpNode(TypeK);
              yyval->attr.name = "INT";
              yyval->size = 1;
              yyval->child[0] = yyvsp[-1];
              yyvsp[-1]->kind.exp = VarK;
              yyvsp[-1]->type = intDType;
           }
#line 1277 "acmc.tab.c"
    break;

  case 8: /* var_declaracao: INT identificador ACOL numero FCOL PV  */
#line 66 "acmc.y"
           { 
              // Declaração de vetor (array)
              yyval = newExpNode(TypeK); 
              yyval->attr.name = "INT";
              yyval->size = yyvsp[-2]->attr.val;
              yyval->child[0] = yyvsp[-4];
              yyvsp[-4]->kind.exp = VarK;
              yyvsp[-4]->type = intDType;
              yyval->child[0]->child[0] = yyvsp[-2];
              yyvsp[-2]->kind.exp = ConstK;
           }
#line 1293 "acmc.tab.c"
    break;

  case 9: /* tipo_especificador: INT  */
#line 81 "acmc.y"
           { 
              // Tipo INT
              yyval = newExpNode(TypeK);
              yyval->attr.name = "INT";
              yyval->type = intDType;
              yyval->size = 1;
           }
#line 1305 "acmc.tab.c"
    break;

  case 10: /* tipo_especificador: VOID  */
#line 89 "acmc.y"
           { 
              // Tipo VOID
              yyval = newExpNode(TypeK);
              yyval->attr.name = "VOID";
              yyval->type = voidDType;
              yyval->size = 1;
           }
#line 1317 "acmc.tab.c"
    break;

  case 11: /* fun_declaracao: INT identificador APAR params FPAR composto_decl  */
#line 100 "acmc.y"
           { 
              // Função com retorno INT
              yyval = newExpNode(TypeK);
              yyval->attr.name = "INT";
              yyval->child[0] = yyvsp[-4];
              yyvsp[-4]->kind.exp = FuncK;
              yyvsp[-4]->type = intDType;
              yyvsp[-4]->child[0] = yyvsp[-2]; // Parâmetros
              yyvsp[-4]->child[1] = yyvsp[0]; // Corpo da função
           }
#line 1332 "acmc.tab.c"
    break;

  case 12: /* fun_declaracao: VOID identificador APAR params FPAR composto_decl  */
#line 111 "acmc.y"
           { 
              // Função com retorno VOID
              yyval = newExpNode(TypeK);
              yyval->attr.name = "VOID";
              yyval->child[0] = yyvsp[-4];
              yyvsp[-4]->kind.exp = FuncK;
              yyvsp[-4]->type = voidDType;
              yyvsp[-4]->child[0] = yyvsp[-2]; // Parâmetros
              yyvsp[-4]->child[1] = yyvsp[0]; // Corpo da função
           }
#line 1347 "acmc.tab.c"
    break;

  case 13: /* params: param_lista  */
#line 124 "acmc.y"
                    { yyval = yyvsp[0]; }
#line 1353 "acmc.tab.c"
    break;

  case 14: /* params: VOID  */
#line 126 "acmc.y"
         { 
            // Função sem parâmetros
            yyval = newExpNode(TypeK);
            yyval->attr.name = "VOID";
            yyval->size = 1;
            yyval->child[0] = NULL;
         }
#line 1365 "acmc.tab.c"
    break;

  case 15: /* param_lista: param_lista VIR param  */
#line 137 "acmc.y"
           { 
              // Adiciona novo parâmetro à lista
              YYSTYPE t = yyvsp[-2];
              if (t != NULL){
                while (t->sibling != NULL)
                   t = t->sibling;
                t->sibling = yyvsp[0];
                yyval = yyvsp[-2];
              }
              else yyval = yyvsp[0];
           }
#line 1381 "acmc.tab.c"
    break;

  case 16: /* param_lista: param  */
#line 148 "acmc.y"
                 { yyval = yyvsp[0]; }
#line 1387 "acmc.tab.c"
    break;

  case 17: /* param: tipo_especificador identificador  */
#line 153 "acmc.y"
       { 
          // Parâmetro simples
          yyval = yyvsp[-1];
          yyval->child[0] = yyvsp[0];
          yyvsp[0]->kind.exp = ParamK;
       }
#line 1398 "acmc.tab.c"
    break;

  case 18: /* param: tipo_especificador identificador ACOL FCOL  */
#line 160 "acmc.y"
       { 
          // Parâmetro do tipo vetor (array)
          yyval = yyvsp[-3];
          yyval->size = 0;
          yyval->child[0] = yyvsp[-2];
          yyvsp[-2]->kind.exp = ParamK;
       }
#line 1410 "acmc.tab.c"
    break;

  case 19: /* composto_decl: ACHAV local_declaracoes statement_lista FCHAV  */
#line 171 "acmc.y"
              { 
                 // Combina declarações locais e comandos
                 YYSTYPE t = yyvsp[-2];
                 if (t != NULL){
                   while (t->sibling != NULL)
                      t = t->sibling;
                   t->sibling = yyvsp[-1];
                   yyval = yyvsp[-2];
                 }
                 else yyval = yyvsp[-1];
              }
#line 1426 "acmc.tab.c"
    break;

  case 20: /* composto_decl: ACHAV FCHAV  */
#line 182 "acmc.y"
                           { yyval = NULL; }
#line 1432 "acmc.tab.c"
    break;

  case 21: /* composto_decl: ACHAV local_declaracoes FCHAV  */
#line 183 "acmc.y"
                                             { yyval = yyvsp[-1]; }
#line 1438 "acmc.tab.c"
    break;

  case 22: /* composto_decl: ACHAV statement_lista FCHAV  */
#line 184 "acmc.y"
                                           { yyval = yyvsp[-1]; }
#line 1444 "acmc.tab.c"
    break;

  case 23: /* local_declaracoes: local_declaracoes var_declaracao  */
#line 189 "acmc.y"
            { 
               // Adiciona declaração de variável à lista local
               YYSTYPE t = yyvsp[-1];
               if (t != NULL){
                 while (t->sibling != NULL)
                    t = t->sibling;
                 t->sibling = yyvsp[0];
                 yyval = yyvsp[-1];
               }
               else yyval = yyvsp[0];
            }
#line 1460 "acmc.tab.c"
    break;

  case 24: /* local_declaracoes: var_declaracao  */
#line 200 "acmc.y"
                           { yyval = yyvsp[0]; }
#line 1466 "acmc.tab.c"
    break;

  case 25: /* statement_lista: statement_lista statement  */
#line 205 "acmc.y"
            { 
              // Concatena comandos na lista
              YYSTYPE t = yyvsp[-1];
              if (t != NULL){
                while (t->sibling != NULL)
                  t = t->sibling;
                t->sibling = yyvsp[0];
                yyval = yyvsp[-1];
              }
              else yyval = yyvsp[0];
            }
#line 1482 "acmc.tab.c"
    break;

  case 26: /* statement_lista: statement  */
#line 216 "acmc.y"
                      { yyval = yyvsp[0]; }
#line 1488 "acmc.tab.c"
    break;

  case 27: /* statement: expressao_decl  */
#line 220 "acmc.y"
                          { yyval = yyvsp[0]; }
#line 1494 "acmc.tab.c"
    break;

  case 28: /* statement: composto_decl  */
#line 221 "acmc.y"
                         { yyval = yyvsp[0]; }
#line 1500 "acmc.tab.c"
    break;

  case 29: /* statement: selecao_decl  */
#line 222 "acmc.y"
                        { yyval = yyvsp[0]; }
#line 1506 "acmc.tab.c"
    break;

  case 30: /* statement: iteracao_decl  */
#line 223 "acmc.y"
                         { yyval = yyvsp[0]; }
#line 1512 "acmc.tab.c"
    break;

  case 31: /* statement: retorno_decl  */
#line 224 "acmc.y"
                        { yyval = yyvsp[0]; }
#line 1518 "acmc.tab.c"
    break;

  case 32: /* statement: load_decl  */
#line 225 "acmc.y"
                     { yyval = yyvsp[0]; }
#line 1524 "acmc.tab.c"
    break;

  case 33: /* statement: quantum_decl  */
#line 226 "acmc.y"
                        { yyval = yyvsp[0]; }
#line 1530 "acmc.tab.c"
    break;

  case 34: /* expressao_decl: expressao PV  */
#line 230 "acmc.y"
                             { yyval = yyvsp[-1]; }
#line 1536 "acmc.tab.c"
    break;

  case 35: /* expressao_decl: PV  */
#line 231 "acmc.y"
                   { /* Comando vazio */ }
#line 1542 "acmc.tab.c"
    break;

  case 36: /* selecao_decl: IF APAR expressao FPAR statement  */
#line 236 "acmc.y"
              { 
                // Comando if sem else
                yyval = newStmtNode(IfK);
                yyval->child[0] = yyvsp[-2]; // condição
                yyval->child[1] = yyvsp[0]; // comando se verdadeiro
              }
#line 1553 "acmc.tab.c"
    break;

  case 37: /* selecao_decl: IF APAR expressao FPAR statement ELSE statement  */
#line 243 "acmc.y"
              { 
                // Comando if com else
                yyval = newStmtNode(IfK);
                yyval->child[0] = yyvsp[-4]; // condição
                yyval->child[1] = yyvsp[-2]; // comando se verdadeiro
                yyval->child[2] = yyvsp[0]; // comando se falso
              }
#line 1565 "acmc.tab.c"
    break;

  case 38: /* iteracao_decl: WHILE APAR expressao FPAR statement  */
#line 254 "acmc.y"
              { 
                // Comando while
                yyval = newStmtNode(WhileK);
                yyval->child[0] = yyvsp[-2]; // condição
                yyval->child[1] = yyvsp[0]; // comando do loop
              }
#line 1576 "acmc.tab.c"
    break;

  case 39: /* retorno_decl: RETURN PV  */
#line 264 "acmc.y"
              { 
                // Retorno sem valor
                yyval = newStmtNode(ReturnK); 
              }
#line 1585 "acmc.tab.c"
    break;

  case 40: /* retorno_decl: RETURN expressao PV  */
#line 269 "acmc.y"
              { 
                // Retorno com valor
                yyval = newStmtNode(ReturnK);
                yyval->child[0] = yyvsp[-1];
              }
#line 1595 "acmc.tab.c"
    break;

  case 41: /* load_decl: LOAD expressao PV  */
#line 278 "acmc.y"
           {
             yyval = newStmtNode(LoadK);
             yyval->child[0] = yyvsp[-1];
           }
#line 1604 "acmc.tab.c"
    break;

  case 42: /* quantum_decl: QUANTUM expressao PV  */
#line 286 "acmc.y"
              {
                yyval = newStmtNode(QuantumK);
                yyval->child[0] = yyvsp[-1];
              }
#line 1613 "acmc.tab.c"
    break;

  case 43: /* expressao: var IGUAL expressao  */
#line 294 "acmc.y"
           { 
             // Atribuição
             yyval = newStmtNode(AssignK);
             yyval->child[0] = yyvsp[-2]; // variável
             yyval->child[1] = yyvsp[0]; // expressão atribuída
           }
#line 1624 "acmc.tab.c"
    break;

  case 44: /* expressao: simples_expressao  */
#line 300 "acmc.y"
                             { yyval = yyvsp[0]; }
#line 1630 "acmc.tab.c"
    break;

  case 45: /* var: identificador  */
#line 305 "acmc.y"
       { yyval = yyvsp[0]; }
#line 1636 "acmc.tab.c"
    break;

  case 46: /* var: identificador ACOL expressao FCOL  */
#line 307 "acmc.y"
       { 
         // Acesso a vetor (array)
         yyval = yyvsp[-3];
         yyval->type = intDType;
         yyval->child[0] = yyvsp[-1]; // índice
       }
#line 1647 "acmc.tab.c"
    break;

  case 47: /* simples_expressao: soma_expressao relacional soma_expressao  */
#line 317 "acmc.y"
                   { 
                     // Expressão com operador relacional
                     yyval = yyvsp[-1];
                     yyval->child[0] = yyvsp[-2];
                     yyval->child[1] = yyvsp[0];
                   }
#line 1658 "acmc.tab.c"
    break;

  case 48: /* simples_expressao: soma_expressao  */
#line 323 "acmc.y"
                                  { yyval = yyvsp[0]; }
#line 1664 "acmc.tab.c"
    break;

  case 49: /* relacional: MENOR  */
#line 328 "acmc.y"
              { 
                // Operador '<'
                yyval = newExpNode(OpK);
                yyval->attr.opr = MENOR;
              }
#line 1674 "acmc.tab.c"
    break;

  case 50: /* relacional: MENIG  */
#line 334 "acmc.y"
              { 
                // Operador '<='
                yyval = newExpNode(OpK);
                yyval->attr.opr = MENIG;
              }
#line 1684 "acmc.tab.c"
    break;

  case 51: /* relacional: MAIOR  */
#line 340 "acmc.y"
              { 
                // Operador '>'
                yyval = newExpNode(OpK);
                yyval->attr.opr = MAIOR;
              }
#line 1694 "acmc.tab.c"
    break;

  case 52: /* relacional: MAIIG  */
#line 346 "acmc.y"
              { 
                // Operador '>='
                yyval = newExpNode(OpK);
                yyval->attr.opr = MAIIG;
              }
#line 1704 "acmc.tab.c"
    break;

  case 53: /* relacional: IGDAD  */
#line 352 "acmc.y"
              { 
                // Operador '=='
                yyval = newExpNode(OpK);
                yyval->attr.opr = IGDAD;
              }
#line 1714 "acmc.tab.c"
    break;

  case 54: /* relacional: DIFER  */
#line 358 "acmc.y"
              { 
                // Operador '!='
                yyval = newExpNode(OpK);
                yyval->attr.opr = DIFER;
              }
#line 1724 "acmc.tab.c"
    break;

  case 55: /* soma_expressao: soma_expressao soma termo  */
#line 367 "acmc.y"
                { 
                  // Operação de adição ou subtração
                  yyval = yyvsp[-1];
                  yyval->child[0] = yyvsp[-2];
                  yyval->child[1] = yyvsp[0];
                }
#line 1735 "acmc.tab.c"
    break;

  case 56: /* soma_expressao: termo  */
#line 373 "acmc.y"
                      { yyval = yyvsp[0]; }
#line 1741 "acmc.tab.c"
    break;

  case 57: /* soma: MAIS  */
#line 378 "acmc.y"
       { 
         // Operador '+'
         yyval = newExpNode(OpK);
         yyval->attr.opr = MAIS;
       }
#line 1751 "acmc.tab.c"
    break;

  case 58: /* soma: SUB  */
#line 384 "acmc.y"
        { 
          // Operador '-'
          yyval = newExpNode(OpK);
          yyval->attr.opr = SUB;
        }
#line 1761 "acmc.tab.c"
    break;

  case 59: /* termo: termo mult fator  */
#line 393 "acmc.y"
         { 
           // Operação de multiplicação ou divisão
           yyval = yyvsp[-1];
           yyval->child[0] = yyvsp[-2];
           yyval->child[1] = yyvsp[0];
         }
#line 1772 "acmc.tab.c"
    break;

  case 60: /* termo: fator  */
#line 399 "acmc.y"
               { yyval = yyvsp[0]; }
#line 1778 "acmc.tab.c"
    break;

  case 61: /* mult: MULT  */
#line 404 "acmc.y"
       { 
         // Operador '*'
         yyval = newExpNode(OpK);
         yyval->attr.opr = MULT;
       }
#line 1788 "acmc.tab.c"
    break;

  case 62: /* mult: DIV  */
#line 410 "acmc.y"
        { 
          // Operador '/'
          yyval = newExpNode(OpK);
          yyval->attr.opr = DIV;
        }
#line 1798 "acmc.tab.c"
    break;

  case 63: /* fator: APAR expressao FPAR  */
#line 419 "acmc.y"
         { 
           // Expressão entre parênteses
           yyval = yyvsp[-1]; 
         }
#line 1807 "acmc.tab.c"
    break;

  case 64: /* fator: var  */
#line 424 "acmc.y"
         { 
           // Variável
           yyval = yyvsp[0]; 
         }
#line 1816 "acmc.tab.c"
    break;

  case 65: /* fator: ativacao  */
#line 429 "acmc.y"
         { 
           // Chamada de função
           yyval = yyvsp[0]; 
         }
#line 1825 "acmc.tab.c"
    break;

  case 66: /* fator: numero  */
#line 434 "acmc.y"
         { 
           // Constante numérica
           yyval = yyvsp[0]; 
         }
#line 1834 "acmc.tab.c"
    break;

  case 67: /* ativacao: identificador APAR arg_lista FPAR  */
#line 442 "acmc.y"
          { 
            // Chamada de função com argumentos
            yyval = newExpNode(CallK);
            yyval->attr.name = yyvsp[-3]->attr.name;
            yyval->child[0] = yyvsp[-1]; // Lista de argumentos
          }
#line 1845 "acmc.tab.c"
    break;

  case 68: /* ativacao: identificador APAR FPAR  */
#line 449 "acmc.y"
          { 
            // Chamada de função sem argumentos
            yyval = newExpNode(CallK);
            yyval->attr.name = yyvsp[-2]->attr.name;
          }
#line 1855 "acmc.tab.c"
    break;

  case 69: /* arg_lista: arg_lista VIR expressao  */
#line 458 "acmc.y"
           { 
             // Adiciona argumento à lista
             YYSTYPE t = yyvsp[-2];
             if (t != NULL){
               while (t->sibling != NULL)
                 t = t->sibling;
               t->sibling = yyvsp[0];
               yyval = yyvsp[-2];
             }
             else yyval = yyvsp[0];
           }
#line 1871 "acmc.tab.c"
    break;

  case 70: /* arg_lista: expressao  */
#line 469 "acmc.y"
                     { yyval = yyvsp[0]; }
#line 1877 "acmc.tab.c"
    break;

  case 71: /* identificador: ID  */
#line 474 "acmc.y"
               { 
                 // Cria nó para identificador
                 yyval = newExpNode(IdK);
                 yyval->attr.name = copyString(tokenString);
               }
#line 1887 "acmc.tab.c"
    break;

  case 72: /* numero: NUM  */
#line 483 "acmc.y"
         { 
           yyval = newExpNode(ConstK);
           yyval->type = intDType;
           yyval->attr.val = atoi(tokenString);
         }
#line 1897 "acmc.tab.c"
    break;


#line 1901 "acmc.tab.c"

      default: break;
    }
  /* User semantic actions sometimes alter yychar, and that requires
     that yytoken be updated with the new translation.  We take the
     approach of translating immediately before every use of yytoken.
     One alternative is translating here after every semantic action,
     but that translation would be missed if the semantic action invokes
     YYABORT, YYACCEPT, or YYERROR immediately after altering yychar or
     if it invokes YYBACKUP.  In the case of YYABORT or YYACCEPT, an
     incorrect destructor might then be invoked immediately.  In the
     case of YYERROR or YYBACKUP, subsequent parser actions might lead
     to an incorrect destructor call or verbose syntax error message
     before the lookahead is translated.  */
  YY_SYMBOL_PRINT ("-> $$ =", YY_CAST (yysymbol_kind_t, yyr1[yyn]), &yyval, &yyloc);

  YYPOPSTACK (yylen);
  yylen = 0;

  *++yyvsp = yyval;

  /* Now 'shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */
  {
    const int yylhs = yyr1[yyn] - YYNTOKENS;
    const int yyi = yypgoto[yylhs] + *yyssp;
    yystate = (0 <= yyi && yyi <= YYLAST && yycheck[yyi] == *yyssp
               ? yytable[yyi]
               : yydefgoto[yylhs]);
  }

  goto yynewstate;


/*--------------------------------------.
| yyerrlab -- here on detecting error.  |
`--------------------------------------*/
yyerrlab:
  /* Make sure we have latest lookahead translation.  See comments at
     user semantic actions for why this is necessary.  */
  yytoken = yychar == YYEMPTY ? YYSYMBOL_YYEMPTY : YYTRANSLATE (yychar);
  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
      yyerror (YY_("syntax error"));
    }

  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse lookahead token after an
         error, discard it.  */

      if (yychar <= YYEOF)
        {
          /* Return failure if at end of input.  */
          if (yychar == YYEOF)
            YYABORT;
        }
      else
        {
          yydestruct ("Error: discarding",
                      yytoken, &yylval);
          yychar = YYEMPTY;
        }
    }

  /* Else will try to reuse lookahead token after shifting the error
     token.  */
  goto yyerrlab1;


/*---------------------------------------------------.
| yyerrorlab -- error raised explicitly by YYERROR.  |
`---------------------------------------------------*/
yyerrorlab:
  /* Pacify compilers when the user code never invokes YYERROR and the
     label yyerrorlab therefore never appears in user code.  */
  if (0)
    YYERROR;
  ++yynerrs;

  /* Do not reclaim the symbols of the rule whose action triggered
     this YYERROR.  */
  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);
  yystate = *yyssp;
  goto yyerrlab1;


/*-------------------------------------------------------------.
| yyerrlab1 -- common code for both syntax error and YYERROR.  |
`-------------------------------------------------------------*/
yyerrlab1:
  yyerrstatus = 3;      /* Each real token shifted decrements this.  */

  /* Pop stack until we find a state that shifts the error token.  */
  for (;;)
    {
      yyn = yypact[yystate];
      if (!yypact_value_is_default (yyn))
        {
          yyn += YYSYMBOL_YYerror;
          if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYSYMBOL_YYerror)
            {
              yyn = yytable[yyn];
              if (0 < yyn)
                break;
            }
        }

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
        YYABORT;


      yydestruct ("Error: popping",
                  YY_ACCESSING_SYMBOL (yystate), yyvsp);
      YYPOPSTACK (1);
      yystate = *yyssp;
      YY_STACK_PRINT (yyss, yyssp);
    }

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END


  /* Shift the error token.  */
  YY_SYMBOL_PRINT ("Shifting", YY_ACCESSING_SYMBOL (yyn), yyvsp, yylsp);

  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturnlab;


/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturnlab;


/*-----------------------------------------------------------.
| yyexhaustedlab -- YYNOMEM (memory exhaustion) comes here.  |
`-----------------------------------------------------------*/
yyexhaustedlab:
  yyerror (YY_("memory exhausted"));
  yyresult = 2;
  goto yyreturnlab;


/*----------------------------------------------------------.
| yyreturnlab -- parsing is finished, clean up and return.  |
`----------------------------------------------------------*/
yyreturnlab:
  if (yychar != YYEMPTY)
    {
      /* Make sure we have latest lookahead translation.  See comments at
         user semantic actions for why this is necessary.  */
      yytoken = YYTRANSLATE (yychar);
      yydestruct ("Cleanup: discarding lookahead",
                  yytoken, &yylval);
    }
  /* Do not reclaim the symbols of the rule whose action triggered
     this YYABORT or YYACCEPT.  */
  YYPOPSTACK (yylen);
  YY_STACK_PRINT (yyss, yyssp);
  while (yyssp != yyss)
    {
      yydestruct ("Cleanup: popping",
                  YY_ACCESSING_SYMBOL (+*yyssp), yyvsp);
      YYPOPSTACK (1);
    }
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif

  return yyresult;
}

#line 490 "acmc.y"


int yyerror(char *message) {
  // Trata erros sintáticos e exibe mensagem com o token e a linha
  fprintf(listing, "ERRO SINTÁTICO: %s. LINHA: %d\n", tokenString, lineno);
  Error = TRUE;
  return 0;
}

static int yylex(void) {
  // Chama a função getToken() do scanner
  return getToken();
}

TreeNode *parse(void) {
  // Inicia a análise sintática e retorna a árvore gerada
  yyparse();
  return savedTree;
}
